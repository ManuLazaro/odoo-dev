# -*- coding: utf-8 -*-

from . import models
from . import pelicula
from . import genero
from . import tecnica
